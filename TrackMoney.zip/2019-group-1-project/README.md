# 2019-group-1-project

## Money Track App

An Android application to track income and expense.

## User Stories

- [ ] User can see Income/Expense history on the main screen
- [ ] User can add Income/Expense on a different screen
- [ ] User can edit previous Income/Expense data
- [ ] User can delete an existing Income/Expense data
- [ ] User can search a specific Income/Expense data based on the date
- [ ] User can add a picture to an Income/Expense

###### Work in progress...
