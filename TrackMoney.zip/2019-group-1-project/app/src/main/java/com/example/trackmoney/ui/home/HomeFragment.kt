package com.example.trackmoney.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import com.example.trackmoney.R
import com.google.android.material.floatingactionbutton.FloatingActionButton




class HomeFragment : Fragment() {

    private lateinit var homeViewModel: HomeViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        homeViewModel =
            ViewModelProviders.of(this).get(HomeViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_home, container, false)
        /*val textView: TextView = root.findViewById(R.id.text_home)
        homeViewModel.text.observe(this, Observer {
            textView.text = it
        })*/
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Called when user taps the Add Income/Expense button
        val fabButton = view.findViewById<FloatingActionButton>(R.id.fab)
        fabButton.setOnClickListener {
            val action  = HomeFragmentDirections.actionNavigationHomeToAddIncomeExpense2()
            action.setId("this is the message...")
            findNavController().navigate(action)
        }

        val list = view.findViewById<Rec>(R.id.)
        val myStringArray1 = ArrayList<String>()


        /*Take the argument from the AddIncomeExpenseFragment*/
        if (arguments != null){
            val args = HomeFragmentArgs.fromBundle(arguments!!)
            myStringArray1.add(args.string)
            val adapterView = AdapterView.


//            Toast.makeText(context, " ${args.string}", Toast.LENGTH_LONG).show()
//            var dummyText: String = ""
//            for(dummy_data in it) {
//                dummyText += dummy_data + "\n"
//            }
//            textView.text = dummyText
//            textHome.text = Arrays.toString(args.string)
//            Toast.makeText(context, " ${args.string}", Toast.LENGTH_LONG).show()

        }
    }
}

//package com.example.trackmoney.ui.home
//
//import android.os.Bundle
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.widget.Button
//import android.widget.TextView
//import androidx.fragment.app.Fragment
//import androidx.lifecycle.Observer
//import androidx.lifecycle.ViewModelProviders
//import androidx.navigation.fragment.findNavController
//import com.example.trackmoney.R
//import com.google.android.material.floatingactionbutton.FloatingActionButton
//
//class HomeFragment : Fragment() {
//
//    private lateinit var homeViewModel: HomeViewModel
//
//    override fun onCreateView(
//        inflater: LayoutInflater,
//        container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View? {
//
//        // Initialize the ViewModel
//        homeViewModel = ViewModelProviders.of(this).get(HomeViewModel::class.java)
//
//        // Find the root
//        val root = inflater.inflate(R.layout.fragment_home, container, false)
//
//        // Get a reference for the textView in home fragment
//        val textView: TextView = root.findViewById(R.id.money_track)
//
//        // Change textView if HomeViewModel text changes
//        homeViewModel.text.observe(this, Observer {
//            var dummyText: String = ""
//            for(dummy_data in it) {
//                dummyText += dummy_data + "\n"
//            }
//            textView.text = dummyText
//        })
//
//        return root
//    }
//
//    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        super.onViewCreated(view, savedInstanceState)
//
//        // Called when user taps the Add Income/Expense button
//        val fabButton = view.findViewById<FloatingActionButton>(R.id.fab)
//        fabButton.setOnClickListener {
//            findNavController().navigate(R.id.addIncomeExpense)
//        }
//    }
//}
//
